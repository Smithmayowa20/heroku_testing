# heroku_testing
Testing django deployment to heroku by deploying a website application.
